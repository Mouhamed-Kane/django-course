from django.db import models
from django.utils import timezone

from django.db.models.aggregates import Max

# Create your models here.
class Departement(models.Model):
    nom = models.CharField(max_length=255)

    class Meta:
        verbose_name_plural = "Départements"

        def __str__(self):
            return self.nom

class Employe(models.Model):
    nom = models.CharField(max_length=255)
    prenom = models.CharField(max_length=255)
    mail = models.CharField(max_length=255)
    tel = models.CharField(max_length=255)
    date_embauche = models.DateTimeField(default=timezone.now, verbose_name="Date Embauche")

    class Meta:
        verbose_name_plural = "Employés"

        def __str__(self):
            return self.prenom


