from .models import Departement, Employe
from django.contrib import admin


# Register your models here.

admin.site.register(Departement)
admin.site.register(Employe)